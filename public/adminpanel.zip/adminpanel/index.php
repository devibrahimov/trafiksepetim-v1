<?php include 'Theme/header.php' ?>
                                        <div class="col-xxl-6">
                                            <div class="card card-bordered h-100">
                    </div>
                </div>
               <?php include 'Theme/footer.php' ?>