<?php
include '../Connect/baglan.php';
include '../Session/Control.php';
include '../Connect/datebase.php';
?>