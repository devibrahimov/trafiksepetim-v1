                <div class="nk-footer">
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                            <div class="nk-footer-copyright"> &copy; 2020 Trafik Sepetim. Tüm Hakları <a href="#">Koaa Medya</a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/bundle.js?ver=1.4.0"></script>
    <script src="assets/js/scripts.js?ver=1.4.0"></script>
    <script src="assets/js/charts/gd-general.js?ver=1.4.0"></script>
                <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.bundle.min.js"></script>
                <script type="text/javascript" src="assets/iconpicker/js/bootstrap-iconpicker.bundle.min.js"></script>
</body>
</html>